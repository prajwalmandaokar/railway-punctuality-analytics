# Power BI file

Build the dashboard in Power BI Desktop by following docs/powerbi_build_guide.md.
Save the finished report here as Railway_Punctuality_Dashboard.pbix.
The .pbix is a binary file and must be created in Power BI Desktop; the measures and theme are provided as files in this folder.
