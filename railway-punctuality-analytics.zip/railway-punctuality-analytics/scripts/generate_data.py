"""
generate_data.py
-----------------
Creates a realistic synthetic dataset for the Railway Punctuality Analytics project.

Outputs (written to data/raw/):
    stations.csv    - station master list (code, name, zone, state, category)
    trains.csv      - train master list (number, name, category, route endpoints)
    train_runs.csv  - one row per train per run date with scheduled and actual times

The data is synthetic and designed to look like real operational data:
    - Delays depend on route, time of day, weekday, season (monsoon/fog), and train category
    - A few "bottleneck" stations add extra delay
    - Some records contain realistic data quality issues (missing actuals, duplicates,
      inconsistent station names) so the cleaning step has real work to do

Run:
    python scripts/generate_data.py
    python scripts/generate_data.py --runs-per-train 60 --seed 7
"""

import argparse
import os
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

RAW_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "raw")

# ---------------------------------------------------------------------------
# Reference data
# ---------------------------------------------------------------------------
STATIONS = [
    # code, name, zone, state, station_category, is_bottleneck
    ("NDLS", "New Delhi", "Northern", "Delhi", "A1", False),
    ("MMCT", "Mumbai Central", "Western", "Maharashtra", "A1", True),
    ("CSMT", "Chhatrapati Shivaji Maharaj Terminus", "Central", "Maharashtra", "A1", True),
    ("HWH", "Howrah Junction", "Eastern", "West Bengal", "A1", False),
    ("MAS", "Chennai Central", "Southern", "Tamil Nadu", "A1", False),
    ("SBC", "KSR Bengaluru City", "South Western", "Karnataka", "A1", False),
    ("PUNE", "Pune Junction", "Central", "Maharashtra", "A", True),
    ("NGP", "Nagpur Junction", "Central", "Maharashtra", "A", False),
    ("BPL", "Bhopal Junction", "West Central", "Madhya Pradesh", "A", False),
    ("JP", "Jaipur Junction", "North Western", "Rajasthan", "A", False),
    ("ADI", "Ahmedabad Junction", "Western", "Gujarat", "A", True),
    ("LKO", "Lucknow Charbagh", "Northern", "Uttar Pradesh", "A", False),
    ("PNBE", "Patna Junction", "East Central", "Bihar", "A", True),
    ("BBS", "Bhubaneswar", "East Coast", "Odisha", "B", False),
    ("VSKP", "Visakhapatnam", "East Coast", "Andhra Pradesh", "A", False),
    ("HYB", "Hyderabad Deccan", "South Central", "Telangana", "A1", False),
    ("ERS", "Ernakulam Junction", "Southern", "Kerala", "A", False),
    ("CBE", "Coimbatore Junction", "Southern", "Tamil Nadu", "B", False),
    ("GWL", "Gwalior Junction", "North Central", "Madhya Pradesh", "B", False),
    ("AGC", "Agra Cantonment", "North Central", "Uttar Pradesh", "B", False),
]

# Each route: (train_number, train_name, category, origin, destination, [intermediate stops])
# Intermediate stops are station codes in travel order.
ROUTES = [
    ("12951", "Mumbai Rajdhani", "Superfast Express", "NDLS", "MMCT", ["BPL", "ADI"]),
    ("12002", "Bhopal Shatabdi", "Shatabdi", "NDLS", "BPL", ["AGC", "GWL"]),
    ("12301", "Howrah Rajdhani", "Rajdhani", "NDLS", "HWH", ["LKO", "PNBE"]),
    ("12621", "Tamil Nadu Express", "Superfast Express", "NDLS", "MAS", ["BPL", "NGP"]),
    ("12627", "Karnataka Express", "Superfast Express", "NDLS", "SBC", ["JP", "NGP"]),
    ("12137", "Punjab Mail", "Mail Express", "CSMT", "HWH", ["NGP", "PNBE"]),
    ("12123", "Deccan Queen", "Superfast Express", "PUNE", "CSMT", []),
    ("11061", "Mumbai Express", "Mail Express", "NGP", "CSMT", ["PUNE"]),
    ("12833", "Howrah Express", "Mail Express", "ADI", "HWH", ["NGP", "PNBE"]),
    ("12259", "Duronto Express", "Duronto", "HWH", "NDLS", ["PNBE", "LKO"]),
    ("12615", "Grand Trunk Express", "Superfast Express", "MAS", "NDLS", ["NGP", "BPL"]),
    ("12658", "Kerala Express", "Superfast Express", "NDLS", "ERS", ["BPL", "NGP", "CBE"]),
    ("12703", "Hyderabad Express", "Superfast Express", "MMCT", "HYB", ["PUNE"]),
    ("12841", "Coromandel Express", "Superfast Express", "HWH", "MAS", ["BBS", "VSKP"]),
    ("12726", "Telangana Express", "Superfast Express", "NDLS", "HYB", ["GWL", "NGP"]),
    ("12009", "Shatabdi Ahmedabad", "Shatabdi", "MMCT", "ADI", []),
    ("12269", "Chennai Duronto", "Duronto", "NDLS", "MAS", ["AGC", "BPL", "NGP"]),
    ("12723", "Andhra Pradesh Express", "Superfast Express", "NDLS", "HYB", ["JP", "NGP"]),
    ("22149", "Pune Express", "Superfast Express", "PUNE", "NGP", []),
    ("12101", "Vidarbha Express", "Mail Express", "NGP", "CSMT", ["PUNE"]),
]

# Base delay (minutes) by train category: long-distance premium trains are usually
# more punctual; ordinary mail trains accumulate more delay.
CATEGORY_BASE_DELAY = {
    "Rajdhani": 4,
    "Shatabdi": 2,
    "Duronto": 5,
    "Superfast Express": 9,
    "Mail Express": 15,
}

BOTTLENECK_EXTRA = 6  # extra minutes added when a train passes a bottleneck station


def season_multiplier(month: int) -> float:
    """Monsoon (Jun-Sep) and winter fog (Dec-Jan) increase delays."""
    if month in (6, 7, 8, 9):
        return 1.35
    if month in (12, 1):
        return 1.25
    return 1.0


def peak_multiplier(hour: int) -> float:
    """Morning and evening peaks cause congestion."""
    if 7 <= hour <= 10 or 17 <= hour <= 20:
        return 1.2
    if 0 <= hour <= 4:
        return 0.85
    return 1.0


def weekday_multiplier(weekday: int) -> float:
    """Friday and Sunday traffic is heavier."""
    return {4: 1.1, 6: 1.08}.get(weekday, 1.0)


def build_stations() -> pd.DataFrame:
    df = pd.DataFrame(
        STATIONS,
        columns=["station_code", "station_name", "railway_zone", "state", "station_category", "is_bottleneck"],
    )
    return df


def build_trains() -> pd.DataFrame:
    rows = []
    for number, name, category, origin, dest, stops in ROUTES:
        rows.append(
            {
                "train_number": number,
                "train_name": name,
                "train_category": category,
                "origin_code": origin,
                "destination_code": dest,
                "num_intermediate_stops": len(stops),
                "route_stops": "-".join([origin] + stops + [dest]),
            }
        )
    return pd.DataFrame(rows)


def simulate_runs(trains: pd.DataFrame, stations: pd.DataFrame, runs_per_train: int,
                  rng: np.random.Generator) -> pd.DataFrame:
    bottleneck_codes = set(stations.loc[stations["is_bottleneck"], "station_code"])
    station_name_lookup = dict(zip(stations["station_code"], stations["station_name"]))
    start_date = datetime(2025, 7, 1)
    records = []

    for _, t in trains.iterrows():
        stops = t["route_stops"].split("-")
        base = CATEGORY_BASE_DELAY.get(t["train_category"], 8)
        bottlenecks_on_route = sum(1 for s in stops if s in bottleneck_codes)

        for _ in range(runs_per_train):
            run_date = start_date + timedelta(days=int(rng.integers(0, 365)))
            hour = int(rng.integers(0, 24))
            dep_hour_min = rng.integers(0, 60)
            scheduled_dep = run_date.replace(hour=hour, minute=int(dep_hour_min))
            journey_minutes = 60 * (len(stops) - 1) + int(rng.integers(120, 720))
            scheduled_arr = scheduled_dep + timedelta(minutes=journey_minutes)

            mult = season_multiplier(run_date.month) * peak_multiplier(hour) * weekday_multiplier(run_date.weekday())
            expected_delay = base * mult + BOTTLENECK_EXTRA * bottlenecks_on_route * 0.6
            # Delays are right-skewed: most runs are near-on-time, a few are very late.
            arr_delay = max(0.0, rng.gamma(shape=1.4, scale=expected_delay / 1.4))
            dep_delay = max(0.0, arr_delay * rng.uniform(0.3, 0.8))

            actual_dep = scheduled_dep + timedelta(minutes=round(dep_delay))
            actual_arr = scheduled_arr + timedelta(minutes=round(arr_delay))

            cancelled = rng.random() < 0.012
            if cancelled:
                actual_dep, actual_arr = None, None
                arr_delay = None

            origin = stops[0]
            dest = stops[-1]
            records.append(
                {
                    "run_id": None,  # assigned after shuffle
                    "train_number": t["train_number"],
                    "run_date": run_date.date().isoformat(),
                    "origin_code": origin,
                    "destination_code": dest,
                    "origin_station_name": station_name_lookup.get(origin, origin),
                    "destination_station_name": station_name_lookup.get(dest, dest),
                    "scheduled_departure": scheduled_dep.strftime("%Y-%m-%d %H:%M"),
                    "actual_departure": actual_dep.strftime("%Y-%m-%d %H:%M") if actual_dep else None,
                    "scheduled_arrival": scheduled_arr.strftime("%Y-%m-%d %H:%M"),
                    "actual_arrival": actual_arr.strftime("%Y-%m-%d %H:%M") if actual_arr else None,
                    "arrival_delay_min": round(arr_delay, 1) if arr_delay is not None else None,
                    "departure_delay_min": round(dep_delay, 1) if not cancelled else None,
                    "is_cancelled": int(cancelled),
                    "bottleneck_stops_on_route": bottlenecks_on_route,
                    "route_stops": t["route_stops"],
                }
            )

    runs = pd.DataFrame(records)
    runs = runs.sample(frac=1, random_state=int(rng.integers(0, 1_000_000))).reset_index(drop=True)
    runs["run_id"] = np.arange(1, len(runs) + 1)
    runs = runs[["run_id"] + [c for c in runs.columns if c != "run_id"]]

    # Inject realistic data quality issues so the cleaning step has work to do
    n = len(runs)
    # 1. Exact duplicate rows (~0.5%)
    dupes = runs.sample(frac=0.005, random_state=1)
    runs = pd.concat([runs, dupes], ignore_index=True)
    # 2. Inconsistent station name casing/spacing (~3%)
    mask = rng.random(len(runs)) < 0.03
    runs.loc[mask, "origin_station_name"] = runs.loc[mask, "origin_station_name"].str.upper() + " "
    # 3. Missing delay values on non-cancelled runs (~1%)
    mask = (runs["is_cancelled"] == 0) & (rng.random(len(runs)) < 0.01)
    runs.loc[mask, "arrival_delay_min"] = np.nan
    # 4. Negative delay outliers from clock/sync errors (~0.2%)
    mask = (runs["is_cancelled"] == 0) & (rng.random(len(runs)) < 0.002)
    runs.loc[mask, "arrival_delay_min"] = -rng.integers(5, 40, size=mask.sum())

    return runs


def main():
    parser = argparse.ArgumentParser(description="Generate synthetic railway punctuality data.")
    parser.add_argument("--runs-per-train", type=int, default=250, help="Run records per train (default 250)")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    args = parser.parse_args()

    os.makedirs(RAW_DIR, exist_ok=True)
    rng = np.random.default_rng(args.seed)

    stations = build_stations()
    trains = build_trains()
    runs = simulate_runs(trains, stations, args.runs_per_train, rng)

    stations.to_csv(os.path.join(RAW_DIR, "stations.csv"), index=False)
    trains.to_csv(os.path.join(RAW_DIR, "trains.csv"), index=False)
    runs.to_csv(os.path.join(RAW_DIR, "train_runs.csv"), index=False)

    print(f"Stations : {len(stations):,} rows")
    print(f"Trains   : {len(trains):,} rows")
    print(f"Train runs: {len(runs):,} rows (includes intentional data quality issues)")
    print(f"Files written to: {os.path.abspath(RAW_DIR)}")


if __name__ == "__main__":
    main()
