"""
clean_and_transform.py
-----------------------
Cleans the raw railway data and builds the star-schema tables used by Power BI.

Input  : data/raw/stations.csv, data/raw/trains.csv, data/raw/train_runs.csv
Output : data/processed/
            fact_train_runs.csv     - one clean row per train run (fact table)
            dim_station.csv         - station dimension
            dim_train.csv           - train dimension
            dim_date.csv            - date dimension (for time intelligence in Power BI)
            data_quality_log.csv    - what was fixed, and how many rows were affected

Cleaning steps:
    1. Remove exact duplicate rows
    2. Standardise station names (trim, title case)
    3. Parse datetime columns
    4. Flag cancelled runs; keep them in the fact table but exclude from delay metrics
    5. Impute missing arrival delay from scheduled vs actual times when possible
    6. Replace impossible negative delays (sync errors) with NaN, then treat as missing
    7. Derive features: delay bucket, on-time flag, hour band, day type, season, month

Run:
    python scripts/clean_and_transform.py
"""

import os

import numpy as np
import pandas as pd

BASE = os.path.join(os.path.dirname(__file__), "..")
RAW = os.path.join(BASE, "data", "raw")
PROCESSED = os.path.join(BASE, "data", "processed")

ON_TIME_THRESHOLD_MIN = 15  # Indian Railways convention: a train is "on time" if within 15 minutes

log_entries = []


def log(step: str, rows_affected: int, note: str = ""):
    log_entries.append({"step": step, "rows_affected": int(rows_affected), "note": note})
    print(f"[{step}] rows affected: {rows_affected:,} {('- ' + note) if note else ''}")


def load_raw():
    stations = pd.read_csv(os.path.join(RAW, "stations.csv"))
    trains = pd.read_csv(os.path.join(RAW, "trains.csv"), dtype={"train_number": str})
    runs = pd.read_csv(os.path.join(RAW, "train_runs.csv"), dtype={"train_number": str})
    log("load", len(runs), "raw train runs loaded")
    return stations, trains, runs


def remove_duplicates(runs: pd.DataFrame) -> pd.DataFrame:
    before = len(runs)
    runs = runs.drop_duplicates(subset=[c for c in runs.columns if c != "run_id"])
    log("remove_duplicates", before - len(runs), "exact duplicate rows removed")
    return runs


def standardise_station_names(runs: pd.DataFrame) -> pd.DataFrame:
    for col in ["origin_station_name", "destination_station_name"]:
        original = runs[col].copy()
        runs[col] = runs[col].str.strip().str.title()
        changed = (original != runs[col]).sum()
        log(f"standardise_{col}", changed, "trimmed whitespace and applied title case")
    return runs


def parse_datetimes(runs: pd.DataFrame) -> pd.DataFrame:
    for col in ["scheduled_departure", "actual_departure", "scheduled_arrival", "actual_arrival"]:
        runs[col] = pd.to_datetime(runs[col], errors="coerce")
    runs["run_date"] = pd.to_datetime(runs["run_date"])
    log("parse_datetimes", len(runs), "converted datetime columns")
    return runs


def handle_cancellations(runs: pd.DataFrame) -> pd.DataFrame:
    cancelled = runs["is_cancelled"] == 1
    log("flag_cancelled", cancelled.sum(), "cancelled runs kept but excluded from delay metrics")
    runs.loc[cancelled, ["arrival_delay_min", "departure_delay_min"]] = np.nan
    return runs


def impute_missing_delays(runs: pd.DataFrame) -> pd.DataFrame:
    """Recompute arrival delay from timestamps where the delay value is missing."""
    missing = runs["arrival_delay_min"].isna() & (runs["is_cancelled"] == 0)
    recomputed = (runs["actual_arrival"] - runs["scheduled_arrival"]).dt.total_seconds() / 60
    fill_mask = missing & recomputed.notna()
    runs.loc[fill_mask, "arrival_delay_min"] = recomputed[fill_mask]
    log("impute_missing_delay", fill_mask.sum(), "filled from actual minus scheduled arrival")
    return runs


def fix_negative_delays(runs: pd.DataFrame) -> pd.DataFrame:
    """Negative arrival delays of several minutes are timestamp errors (train cannot arrive early by that much)."""
    neg = runs["arrival_delay_min"] < -5
    log("fix_negative_delay", neg.sum(), "impossible early arrivals set to 0 (clock sync error)")
    runs.loc[neg, "arrival_delay_min"] = 0.0
    # Small negatives (early by a few minutes) are legitimate; keep them.
    return runs


def derive_features(runs: pd.DataFrame) -> pd.DataFrame:
    runs["arrival_delay_min"] = runs["arrival_delay_min"].clip(lower=0)
    runs["is_on_time"] = np.where(
        runs["arrival_delay_min"].isna(), np.nan,
        (runs["arrival_delay_min"] <= ON_TIME_THRESHOLD_MIN).astype(float),
    )

    # Buckets align with the 15-minute on-time threshold so on-time runs form one band
    bins = [-np.inf, ON_TIME_THRESHOLD_MIN, 30, 60, 120, np.inf]
    labels = ["0-15 min (On time)", "16-30 min", "31-60 min", "61-120 min", "120+ min"]
    runs["delay_bucket"] = pd.cut(runs["arrival_delay_min"], bins=bins, labels=labels, right=True)
    runs["delay_bucket"] = runs["delay_bucket"].astype(str).replace("nan", "Cancelled")
    runs.loc[runs["is_cancelled"] == 1, "delay_bucket"] = "Cancelled"

    hour = runs["scheduled_departure"].dt.hour
    runs["departure_hour"] = hour
    runs["time_band"] = pd.cut(
        hour,
        bins=[-1, 5, 9, 12, 16, 20, 23],
        labels=["Late Night", "Morning Peak", "Midday", "Afternoon", "Evening Peak", "Night"],
    ).astype(str)

    runs["day_of_week"] = runs["run_date"].dt.day_name()
    runs["day_type"] = np.where(runs["run_date"].dt.weekday >= 5, "Weekend", "Weekday")
    runs["month"] = runs["run_date"].dt.month
    runs["month_name"] = runs["run_date"].dt.strftime("%b")
    runs["season"] = runs["month"].map(
        lambda m: "Monsoon" if m in (6, 7, 8, 9) else ("Winter" if m in (12, 1, 2) else "Summer/Post-Monsoon")
    )
    runs["delay_minutes_for_avg"] = runs["arrival_delay_min"]  # explicit measure column for Power BI

    log("derive_features", len(runs), "delay_bucket, is_on_time, time_band, day_type, season added")
    return runs


def build_dim_date(runs: pd.DataFrame) -> pd.DataFrame:
    dates = pd.date_range(runs["run_date"].min(), runs["run_date"].max(), freq="D")
    dim = pd.DataFrame({"date": dates})
    dim["year"] = dim["date"].dt.year
    dim["month"] = dim["date"].dt.month
    dim["month_name"] = dim["date"].dt.strftime("%b")
    dim["quarter"] = "Q" + dim["date"].dt.quarter.astype(str)
    dim["week_of_year"] = dim["date"].dt.isocalendar().week.astype(int)
    dim["day_of_week"] = dim["date"].dt.day_name()
    dim["day_type"] = np.where(dim["date"].dt.weekday >= 5, "Weekend", "Weekday")
    dim["season"] = dim["month"].map(
        lambda m: "Monsoon" if m in (6, 7, 8, 9) else ("Winter" if m in (12, 1, 2) else "Summer/Post-Monsoon")
    )
    dim["is_monsoon"] = (dim["season"] == "Monsoon").astype(int)
    return dim


def build_dim_station(stations: pd.DataFrame) -> pd.DataFrame:
    stations = stations.copy()
    stations["station_name"] = stations["station_name"].str.strip().str.title()
    stations["is_bottleneck"] = stations["is_bottleneck"].astype(int)
    return stations


def main():
    os.makedirs(PROCESSED, exist_ok=True)
    stations, trains, runs = load_raw()

    runs = remove_duplicates(runs)
    runs = standardise_station_names(runs)
    runs = parse_datetimes(runs)
    runs = handle_cancellations(runs)
    runs = impute_missing_delays(runs)
    runs = fix_negative_delays(runs)
    runs = derive_features(runs)

    # Attach bottleneck flag for origin/destination for analysis
    bottleneck_codes = set(stations.loc[stations["is_bottleneck"] == True, "station_code"])  # noqa: E712
    runs["route_has_bottleneck"] = runs["route_stops"].apply(
        lambda s: int(any(code in bottleneck_codes for code in s.split("-")))
    )

    dim_station = build_dim_station(stations)
    dim_train = trains.copy()
    dim_date = build_dim_date(runs)

    runs.to_csv(os.path.join(PROCESSED, "fact_train_runs.csv"), index=False)
    dim_station.to_csv(os.path.join(PROCESSED, "dim_station.csv"), index=False)
    dim_train.to_csv(os.path.join(PROCESSED, "dim_train.csv"), index=False)
    dim_date.to_csv(os.path.join(PROCESSED, "dim_date.csv"), index=False)
    pd.DataFrame(log_entries).to_csv(os.path.join(PROCESSED, "data_quality_log.csv"), index=False)

    print("\nProcessed files written to data/processed/")
    print(f"Final fact rows: {len(runs):,}")
    print(f"Overall on-time rate (non-cancelled): {runs['is_on_time'].mean():.1%}")


if __name__ == "__main__":
    main()
