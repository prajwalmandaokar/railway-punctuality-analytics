# Data Dictionary

## Raw files (`data/raw/`)

### stations.csv
| Column | Type | Description |
|---|---|---|
| station_code | text | Unique station code, e.g. NDLS, CSMT |
| station_name | text | Full station name |
| railway_zone | text | Indian Railways zone (e.g. Western, Central) |
| state | text | State where the station is located |
| station_category | text | Station category (A1, A, B) by footfall and importance |
| is_bottleneck | 0/1 | 1 if the station is a known congestion point |

### trains.csv
| Column | Type | Description |
|---|---|---|
| train_number | text | 5-digit train number (kept as text to preserve leading digits) |
| train_name | text | Train name |
| train_category | text | Rajdhani, Shatabdi, Duronto, Superfast Express, or Mail Express |
| origin_code | text | Starting station code |
| destination_code | text | Terminal station code |
| num_intermediate_stops | integer | Number of stops between origin and destination |
| route_stops | text | Full route as station codes joined by hyphens |

### train_runs.csv
One row per train per run date. Contains intentional data quality issues (duplicates, inconsistent names, missing or impossible delay values).

| Column | Type | Description |
|---|---|---|
| run_id | integer | Row identifier |
| train_number | text | Links to trains.csv |
| run_date | date | Date the train ran |
| origin_code, destination_code | text | Route endpoints |
| origin_station_name, destination_station_name | text | Station names (raw, not standardised) |
| scheduled_departure, scheduled_arrival | datetime | Timetabled times |
| actual_departure, actual_arrival | datetime | Actual times (blank if cancelled) |
| arrival_delay_min | decimal | Minutes late at arrival (blank if cancelled or missing) |
| departure_delay_min | decimal | Minutes late at departure |
| is_cancelled | 0/1 | 1 if the run was cancelled |
| bottleneck_stops_on_route | integer | Number of bottleneck stations on the route |
| route_stops | text | Route as station codes |

## Processed files (`data/processed/`)

### fact_train_runs.csv
Cleaned fact table. All columns from `train_runs.csv` (cleaned), plus:

| Column | Type | Description |
|---|---|---|
| is_on_time | 1/0 (blank if cancelled) | 1 if arrival delay is 15 minutes or less |
| delay_bucket | text | 0-15 min (On time), 16-30 min, 31-60 min, 61-120 min, 120+ min, or Cancelled |
| departure_hour | integer | Hour of scheduled departure (0-23) |
| time_band | text | Late Night, Morning Peak, Midday, Afternoon, Evening Peak, or Night |
| day_of_week | text | Monday to Sunday |
| day_type | text | Weekday or Weekend |
| month, month_name | integer, text | Month of run date |
| season | text | Monsoon (Jun-Sep), Winter (Dec-Feb), or Summer/Post-Monsoon |
| route_has_bottleneck | 0/1 | 1 if any stop on the route is a bottleneck station |
| delay_minutes_for_avg | decimal | Copy of arrival_delay_min used as a clean measure column |

### dim_station.csv, dim_train.csv
Cleaned versions of the master files. Station names are title-cased. `is_bottleneck` is stored as 0/1.

### dim_date.csv
One row per calendar day in the data range.

| Column | Description |
|---|---|
| date | Calendar date (primary key, marked as the date table in Power BI) |
| year, month, month_name, quarter, week_of_year | Standard calendar attributes |
| day_of_week, day_type, season, is_monsoon | Day and season attributes |

### data_quality_log.csv
Every cleaning step with the number of rows it affected. Loaded into Power BI's Data Quality page.

## Key business rules

1. **On time** = arrival delay of 15 minutes or less.
2. **Cancelled runs** have no delay value. They are counted in cancellation rate, not in delay averages.
3. **Negative delays** below -5 minutes are treated as clock errors and set to 0.
4. **Duplicates** are removed on every column except `run_id`.
