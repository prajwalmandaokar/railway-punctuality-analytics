# Business Questions

The dashboard is built to answer these questions. Each one maps to a SQL query in `sql/02_analysis_queries.sql` and a visual in Power BI.

| # | Question | Who asks | SQL query | Power BI page |
|---|---|---|---|---|
| 1 | How punctual is the network overall? | Operations head | Q1 | Executive Overview |
| 2 | Which train categories are most reliable? | Product / passenger experience | Q2 | Executive Overview |
| 3 | Which routes are the worst performers? | Divisional manager | Q3 | Route Performance |
| 4 | Which time bands cause the most delay? | Train controller | Q4 | Time Patterns |
| 5 | Is punctuality improving or worsening month to month? | Strategy team | Q5 | Executive Overview |
| 6 | How much does monsoon season hurt punctuality? | Maintenance planning | Q6 | Time Patterns |
| 7 | Do bottleneck stations cost us time on routes that pass through them? | Infrastructure planning | Q7 | Route Performance |
| 8 | What does the delay distribution look like, and how many runs are severely late? | Operations head | Q8 | Executive Overview |
| 9 | Which origin stations generate the most late departures? | Station managers | Q9 | Route Performance |
| 10 | Are weekends or specific weekdays worse? | Scheduling team | Q10 | Time Patterns |
| 11 | How much of the data was cleaned, and can we trust the numbers? | Analytics lead | Q11 | Data Quality |
| 12 | If we cut delays by X minutes, how much does on-time performance improve? | Operations head | Power BI what-if | What-If Simulator |

## Definitions used throughout

- **On time:** arrival delay of 15 minutes or less. This matches the Indian Railways convention for punctuality reporting.
- **Cancelled runs:** excluded from delay metrics, but included in the cancellation rate.
- **Bottleneck station:** a station flagged `is_bottleneck = 1` in `dim_station`. These represent high-congestion junctions.
- **Route has bottleneck:** at least one stop on the train's route (origin to destination) is a bottleneck station.

## Limitations

- The dataset is **synthetic**. It is designed to reflect realistic patterns (monsoon effects, peak-hour congestion, route differences), but it is not official railway data.
- Only 20 trains and 20 stations are included, so results should be read as a demonstration of method, not as network-wide findings.
- Year-over-year comparisons need more than one year of data.
