# Power BI Build Guide: Railway Punctuality Dashboard

This guide walks you through building the dashboard from the processed CSV files, step by step. Estimated time: 4 to 6 hours for a first build.

**What you will build:** a 4-page report with a what-if simulator, covering network KPIs, route and station performance, time patterns, and bottleneck analysis.

---

## Step 0: Prerequisites

| Item | Requirement |
|---|---|
| Software | Power BI Desktop (free, Windows). Download from the Microsoft Store or powerbi.microsoft.com |
| Data | Run the Python scripts first so `data/processed/` contains the CSV files |
| Skill level | Basic Power BI. Familiarity with DAX is helpful but not required |

Run the pipeline before opening Power BI:

```bash
pip install -r requirements.txt
python scripts/generate_data.py
python scripts/clean_and_transform.py
```

Check that these files now exist in `data/processed/`:
- `fact_train_runs.csv`
- `dim_station.csv`
- `dim_train.csv`
- `dim_date.csv`
- `data_quality_log.csv`

---

## Step 1: Load the data

1. Open Power BI Desktop and select **Get data > Text/CSV**.
2. Navigate to `data/processed/fact_train_runs.csv` and select **Transform Data** (not Load). This opens Power Query.
3. In Power Query, check the column types. Set these if they are wrong:

| Column | Type |
|---|---|
| `run_date` | Date |
| `scheduled_departure`, `actual_departure`, `scheduled_arrival`, `actual_arrival` | Date/Time |
| `arrival_delay_min`, `departure_delay_min` | Decimal Number |
| `is_on_time` | Decimal Number |
| `is_cancelled`, `route_has_bottleneck`, `bottleneck_stops_on_route` | Whole Number |
| `train_number` | Text (important: keeps leading characters intact) |

4. Rename the query to `fact_train_runs` in the Queries pane.
5. Repeat for the other tables: `dim_station`, `dim_train`, `dim_date`, and `data_quality_log`. Load each as a separate query.
6. Select **Close & Apply**.

**Checkpoint:** the Data pane shows 5 tables. `fact_train_runs` has about 5,000 rows.

---

## Step 2: Build the data model (star schema)

Go to the **Model view** (the third icon on the left sidebar).

Create these relationships. Drag the key from the dimension to the fact table, or use **Manage relationships**.

| From (one side) | To (many side) | Column | Cardinality | Cross-filter |
|---|---|---|---|---|
| `dim_date[date]` | `fact_train_runs[run_date]` | date | One to many | Single |
| `dim_train[train_number]` | `fact_train_runs[train_number]` | train_number | One to many | Single |
| `dim_station[station_code]` | `fact_train_runs[origin_code]` | station code | One to many | Single |

Notes:
- Leave `destination_code` unconnected. Two relationships to the same dimension cause ambiguity. Instead, use `USERELATIONSHIP` in DAX if you need destination analysis.
- Mark `dim_date` as a date table: right-click `dim_date` in the Data pane, choose **Mark as date table**, and select the `date` column.

**Checkpoint:** the Model view shows a star layout, with the fact table in the centre and three dimensions around it.

---

## Step 3: Set up the what-if parameter

1. Go to **Modeling > New Parameter > Numeric range**.
2. Fill in:
   - Name: `Delay Reduction`
   - Minimum: `0`
   - Maximum: `30`
   - Increment: `1`
   - Default: `0`
   - Add slicer to this page: checked
3. Click **OK**. Power BI creates a table called `Delay Reduction` and a measure called `Delay Reduction Value`.

This slider powers the "what if we cut delays by X minutes" scenario.

---

## Step 4: Create the measures

1. In the Data pane, right-click the canvas and choose **New table**, or type `_Measures = {1}` in a new table. Name it `_Measures` and delete the extra column it creates.
2. For each measure in `powerbi/dax_measures.dax`:
   - Select the `_Measures` table.
   - Choose **New measure** from the ribbon.
   - Paste the name and formula, without the `Measure Name =` line being duplicated. The part before `=` is the measure name.
3. Set the display format for percentage measures (`On-Time %`, `Cancellation Rate %`, `Severe Delay %`, and so on): select the measure, go to **Measure tools > Format**, and choose **Percentage**.

**Important:** Power BI does not run the `// comment` lines, but it will show errors if you paste the whole file at once. Copy one measure at a time.

**Checkpoint:** In a blank table visual, dragging `On-Time %` shows a value between 60% and 70%.

---

## Step 5: Apply the dark theme

1. Go to **View > Themes > Browse for themes**.
2. Select `powerbi/theme.json` from the project folder.
3. The theme sets the colour palette, fonts, and background for all visuals.

---

## Step 6: Build Page 1: Executive Overview

Rename the page tab to **Executive Overview**.

Lay out visuals in this order, from top left to bottom right:

1. **Title text box:** "Railway Punctuality: Executive Overview". Add a subtitle: "Synthetic dataset, July 2025 to June 2026".
2. **KPI cards (top row, 4 cards):**
   - `On-Time %`
   - `Avg Arrival Delay (min)`
   - `Cancellation Rate %`
   - `Total Train Runs`
3. **Line chart: monthly on-time trend**
   - X-axis: `dim_date[month_name]` (sort by `dim_date[month]`)
   - Y-axis: `On-Time %`
   - Title: "On-time % by month"
4. **Clustered bar chart: on-time % by train category**
   - Y-axis: `dim_train[train_category]`
   - X-axis: `On-Time %`
5. **Slicers (left sidebar):** `dim_date[season]`, `dim_date[day_type]`, `dim_train[train_category]`

**Format tips:**
- Set the card background to a slightly lighter shade than the page.
- Turn off the chart gridlines in **Format > Y-axis > Gridlines**.
- Use conditional formatting on KPI cards: **Format > Callout value > Font colour > fx**, and link to a rule using `Performance Status`.

---

## Step 7: Build Page 2: Route and Station Performance

Rename the page to **Route Performance**.

1. **Table visual (main):** columns `dim_train[train_name]`, `dim_train[route_stops]`, `Completed Runs`, `Avg Arrival Delay (min)`, `On-Time %`. Sort by `Avg Arrival Delay (min)`, descending.
2. **Bar chart: Top 10 origin stations by late departures**
   - Axis: `dim_station[station_name]`
   - Values: count of `fact_train_runs` rows where `arrival_delay_min > 15`. Use a measure called `Late Departures` if preferred.
3. **Bar chart: Bottleneck vs non-bottleneck routes**
   - Axis: `fact_train_runs[route_has_bottleneck]` (rename labels via **Format > Data labels**: 1 = "Via bottleneck", 0 = "Clear route")
   - Values: `Avg Arrival Delay (min)`
4. **Card: Bottleneck Delay Penalty (min)**. Add a text box below it: "Average extra minutes on routes passing a bottleneck station."

**Drill-through (recommended):**
1. Create a new page called **Train Detail**.
2. Set **Drill-through fields** to `dim_train[train_name]`.
3. Add a line chart of daily delay for that train, plus a table of its recent runs.
4. Now right-click any train name on Page 2 and choose **Drill through > Train Detail**.

---

## Step 8: Build Page 3: Time Patterns

Rename the page to **Time Patterns**.

1. **Column chart: delay by time band**
   - Axis: `fact_train_runs[time_band]`. Sort by `Avg Arrival Delay (min)` if you prefer.
   - Values: `Avg Arrival Delay (min)`
2. **Heatmap-style matrix:** rows `fact_train_runs[day_of_week]`, columns `fact_train_runs[time_band]`, values `Avg Arrival Delay (min)`. Turn on background colour conditional formatting (**Format > Cell elements > Background colour**).
3. **Column chart: Average delay by day of week** (Monday to Sunday order: sort using `day_of_week` sort-by column or manual sort).
4. **Line chart: 3-month rolling average** using `Avg Delay 3-Month Rolling` against `dim_date[date]`.
5. **Card: Avg Delay YoY Change** (requires a full year of data, so it may show blank for this dataset. Explain this in a note).

---

## Step 9: Build Page 4: What-If Simulator

Rename the page to **What-If Simulator**.

1. Add the **Delay Reduction** slicer (it was created in Step 3). Style it as a horizontal slider.
2. Add three KPI cards:
   - `On-Time %` (current, baseline)
   - `Scenario On-Time %` (after the reduction)
   - `Scenario Uplift (pts)`
3. Add a clustered column chart comparing `On-Time %` and `Scenario On-Time %` by `dim_train[train_category]`.
4. Add a text box explaining the logic: "Reduces every run's arrival delay by the selected minutes, then counts runs within 15 minutes."

**Test it:** move the slider to 10. The scenario on-time % should rise noticeably. If it does not change, check that `Delay Reduction Value` is being used in the measure.

---

## Step 10: Add a Data Quality page (optional but impressive)

1. Create a page called **Data Quality**.
2. Add a table visual from `data_quality_log` showing `step`, `rows_affected`, `note`.
3. Add a bar chart of `rows_affected` by `step`.
4. Add a text box: "Cleaning removed duplicates, standardised station names, imputed missing delays, and corrected impossible values. Full steps are in `scripts/clean_and_transform.py`."

Recruiters and interviewers often look for this. It shows you think about data reliability.

---

## Step 11: Final polish

- **Page navigation:** add buttons on each page that link to the others (**Insert > Buttons > Navigator > Page navigator**).
- **Tooltips:** create a tooltip page with a small chart and set it as the tooltip for the route table.
- **Bookmarks:** create one bookmark per scenario (for example, "Monsoon Season" and "Weekend Only") to show guided storytelling.
- **Titles:** make every visual title a finding, not a label. For example, change "Delay by time band" to "Evening peak adds the most delay."
- **Remove clutter:** delete unused fields and turn off visual headers you do not need.

---

## Step 12: Publish and save

1. Save the file as `Railway_Punctuality_Dashboard.pbix` in the project's `powerbi/` folder.
2. Export a PDF copy: **File > Export > Export to PDF**. Add it to `docs/` so reviewers can see the dashboard without installing Power BI.
3. Take screenshots of each page and save them to `docs/screenshots/`. Add them to the README.
4. Optional: **Publish to web** or **Publish to Power BI Service** if you have a free account. Add the link to your resume.

---

## Troubleshooting

| Problem | Likely cause and fix |
|---|---|
| `On-Time %` shows blank | Check that the `is_on_time` column is Decimal, not Text. Re-check the relationship to `dim_date`. |
| Dates appear as numbers | Set the column type to Date in Power Query. |
| Slicer for `season` shows nothing | `season` lives in both `fact_train_runs` and `dim_date`. Use the one from `dim_date`. |
| Scenario slider changes nothing | Make sure the slicer is connected to the `Delay Reduction` table, not a column in another table. |
| Time-intelligence measures return blank | `dim_date` must be marked as a date table, and the date range must cover the months you are filtering. |
| Relationship warning about ambiguity | Only connect `origin_code`. Do not connect `destination_code` to `dim_station`. |
| `train_number` loses leading zeros | Set the column to Text in Power Query before loading. |

---

## What to write about this project

When you describe this project on your resume or in an interview, lead with the business question and the recommendation, not the tools. For example:

> "Built a Power BI dashboard analysing 5,000 synthetic train runs across 20 routes. Found that routes passing a bottleneck station run an average of X minutes later than clear routes, and built a what-if simulator showing that a 10-minute delay reduction on those routes would lift on-time performance by Y points."

Fill in X and Y with the numbers from your own dashboard.
