# Key Findings

These findings come from the synthetic dataset (5,001 clean train runs, July 2025 to June 2026, 20 trains, 20 stations). Re-check the numbers against your own dashboard after building it, since small differences can come from filter settings.

## Headline numbers

- **On-time performance:** 66.8% of completed runs arrived within 15 minutes of schedule.
- **Average arrival delay:** 14.1 minutes (completed runs only).
- **Cancellation rate:** 1.2% of runs.
- **Delay distribution:** most late runs fall in the 16 to 30 minute band (about 1,057 runs). Runs delayed more than 60 minutes are rare (74 runs in total).

## Finding 1: Bottleneck stations are the biggest controllable delay source

Routes that pass through a bottleneck station average **17.6 minutes** of delay, compared with **9.9 minutes** for routes that avoid them. That is a penalty of about **7.7 minutes per run**.

On-time rate tells the same story: 57% of runs on bottleneck routes arrive on time, against 78% on clear routes.

*Recommendation:* prioritise capacity investment or timetable buffers at bottleneck stations. The what-if simulator lets you test how much on-time performance would improve if delays were cut by a chosen number of minutes.

## Finding 2: Monsoon season adds the most predictable delay

Monsoon runs (June to September) average **16.1 minutes** of delay, compared with **12.5 minutes** in the summer and post-monsoon period. That is about 29% worse.

*Recommendation:* schedule maintenance and speed restrictions outside the monsoon window, and add timetable padding for monsoon months on the routes most affected.

## Finding 3: Evening peak is the worst time band

Evening peak departures average **15.4 minutes** of delay, the highest of any time band. Late night runs are the most punctual at **13.1 minutes**.

*Recommendation:* review crew and platform allocation for 5pm to 8pm departures before adding new services in that window.

## Finding 4: Weekends are slightly worse than weekdays

Weekend runs average **14.8 minutes** of delay, compared with **13.8 minutes** on weekdays.

## Finding 5: Train category shows the widest gap

Shatabdi trains average **5.7 minutes** of delay with a 92% on-time rate, while Mail Express trains average **24.3 minutes** with only 40% on time. Superfast Express trains sit in between at 13.6 minutes and 66% on time.

This gap is larger than the bottleneck penalty, but the two are probably linked: Mail trains travel longer, slower routes that may pass more congested stations. Separating the two effects would need a model that controls for both, which is a good next step.

---

## Limitations to state in interviews

- The data is synthetic. The patterns are built in on purpose (monsoon, peaks, bottlenecks), so the findings show analytical method, not real railway performance.
- With only one year of data, year-over-year comparisons are not possible.
- Causality cannot be proven from this data alone. The bottleneck effect is an association the data supports, and would need operational data to confirm.

## What I would do next with real data

1. Obtain actual running-room and track-capacity data for bottleneck stations.
2. Add weather data (rainfall, fog visibility) to test the monsoon effect directly.
3. Build a simple delay-prediction model (Python, scikit-learn) and show it in the dashboard as a forecast page.
