-- ============================================================================
-- 02_analysis_queries.sql
-- Business questions answered with SQL before building the Power BI dashboard.
-- Each query is numbered to match the questions in docs/business_questions.md.
-- ============================================================================
USE railway_analytics;

-- Q1. Overall network KPIs: on-time rate, average delay, cancellation rate
SELECT
    COUNT(*)                                                    AS total_runs,
    SUM(CASE WHEN is_cancelled = 1 THEN 1 ELSE 0 END)           AS cancelled_runs,
    ROUND(100 * AVG(CASE WHEN is_cancelled = 1 THEN 1.0 ELSE 0 END), 2) AS cancellation_rate_pct,
    ROUND(100 * AVG(is_on_time), 2)                             AS on_time_pct,      -- AVG ignores NULLs (cancelled)
    ROUND(AVG(arrival_delay_min), 1)                            AS avg_arrival_delay_min,
    ROUND(AVG(CASE WHEN arrival_delay_min <= 60 THEN arrival_delay_min END), 1) AS avg_delay_excl_extreme_min
FROM fact_train_runs;

-- Q2. On-time performance by train category (which trains are most reliable?)
SELECT
    t.train_category,
    COUNT(*)                          AS runs,
    ROUND(100 * AVG(f.is_on_time), 2) AS on_time_pct,
    ROUND(AVG(f.arrival_delay_min), 1) AS avg_delay_min
FROM fact_train_runs f
JOIN dim_train t ON t.train_number = f.train_number
WHERE f.is_cancelled = 0
GROUP BY t.train_category
ORDER BY on_time_pct DESC;

-- Q3. Worst routes by average delay (minimum 30 runs for a fair comparison)
SELECT
    t.train_name,
    t.route_stops,
    COUNT(*)                           AS runs,
    ROUND(AVG(f.arrival_delay_min), 1) AS avg_delay_min,
    ROUND(100 * AVG(f.is_on_time), 2)  AS on_time_pct
FROM fact_train_runs f
JOIN dim_train t ON t.train_number = f.train_number
WHERE f.is_cancelled = 0
GROUP BY t.train_name, t.route_stops
HAVING COUNT(*) >= 30
ORDER BY avg_delay_min DESC
LIMIT 10;

-- Q4. Delay by time band (when in the day do delays peak?)
SELECT
    time_band,
    COUNT(*)                           AS runs,
    ROUND(AVG(arrival_delay_min), 1)   AS avg_delay_min,
    ROUND(100 * AVG(is_on_time), 2)    AS on_time_pct
FROM fact_train_runs
WHERE is_cancelled = 0
GROUP BY time_band
ORDER BY avg_delay_min DESC;

-- Q5. Monthly trend with month-over-month change (window function)
WITH monthly AS (
    SELECT
        DATE_FORMAT(run_date, '%Y-%m') AS year_month,
        ROUND(100 * AVG(is_on_time), 2) AS on_time_pct,
        ROUND(AVG(arrival_delay_min), 1) AS avg_delay_min
    FROM fact_train_runs
    WHERE is_cancelled = 0
    GROUP BY DATE_FORMAT(run_date, '%Y-%m')
)
SELECT
    year_month,
    on_time_pct,
    avg_delay_min,
    ROUND(avg_delay_min - LAG(avg_delay_min) OVER (ORDER BY year_month), 1) AS mom_change_min
FROM monthly
ORDER BY year_month;

-- Q6. Monsoon vs non-monsoon impact
SELECT
    season,
    COUNT(*)                           AS runs,
    ROUND(AVG(arrival_delay_min), 1)   AS avg_delay_min,
    ROUND(100 * AVG(is_on_time), 2)    AS on_time_pct
FROM fact_train_runs
WHERE is_cancelled = 0
GROUP BY season
ORDER BY avg_delay_min DESC;

-- Q7. Do bottleneck stations hurt punctuality? (route-level comparison)
SELECT
    route_has_bottleneck,
    CASE WHEN route_has_bottleneck = 1 THEN 'Route passes a bottleneck'
         ELSE 'No bottleneck on route' END  AS route_type,
    COUNT(*)                                AS runs,
    ROUND(AVG(arrival_delay_min), 1)        AS avg_delay_min,
    ROUND(100 * AVG(is_on_time), 2)         AS on_time_pct
FROM fact_train_runs
WHERE is_cancelled = 0
GROUP BY route_has_bottleneck;

-- Q8. Delay distribution (for the histogram visual)
SELECT
    delay_bucket,
    COUNT(*) AS runs,
    ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_of_runs
FROM fact_train_runs
GROUP BY delay_bucket
ORDER BY FIELD(delay_bucket, '0-15 min (On time)', '16-30 min',
               '31-60 min', '61-120 min', '120+ min', 'Cancelled');

-- Q9. Top 5 origin stations by number of late departures (>15 min)
SELECT
    d.station_name,
    d.is_bottleneck,
    COUNT(*) AS late_departures
FROM fact_train_runs f
JOIN dim_station d ON d.station_code = f.origin_code
WHERE f.arrival_delay_min > 15
GROUP BY d.station_name, d.is_bottleneck
ORDER BY late_departures DESC
LIMIT 5;

-- Q10. Day-of-week pattern
SELECT
    day_of_week,
    ROUND(AVG(arrival_delay_min), 1)  AS avg_delay_min,
    ROUND(100 * AVG(is_on_time), 2)   AS on_time_pct
FROM fact_train_runs
WHERE is_cancelled = 0
GROUP BY day_of_week
ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday',
               'Friday', 'Saturday', 'Sunday');

-- Q11. Data quality check: what was cleaned?
SELECT * FROM data_quality_log ORDER BY rows_affected DESC;
