-- ============================================================================
-- 01_schema_and_load.sql
-- Railway Punctuality Analytics: MySQL star schema and data load
-- ============================================================================
-- Run in MySQL 8.0+ (MySQL Workbench, DBeaver, or the mysql CLI).
-- Before running, copy the CSV files from data/processed/ to a folder the
-- MySQL server can read, or use LOCAL INFILE (see the README).
-- ============================================================================

CREATE DATABASE IF NOT EXISTS railway_analytics
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE railway_analytics;

-- Drop in dependency order so the script can be re-run
DROP TABLE IF EXISTS fact_train_runs;
DROP TABLE IF EXISTS dim_train;
DROP TABLE IF EXISTS dim_station;
DROP TABLE IF EXISTS dim_date;
DROP TABLE IF EXISTS data_quality_log;

-- ---------------------------------------------------------------------------
-- Dimension: stations
-- ---------------------------------------------------------------------------
CREATE TABLE dim_station (
    station_code      VARCHAR(10)  PRIMARY KEY,
    station_name      VARCHAR(120) NOT NULL,
    railway_zone      VARCHAR(60),
    state             VARCHAR(60),
    station_category  VARCHAR(5),
    is_bottleneck     TINYINT(1) NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Dimension: trains
-- ---------------------------------------------------------------------------
CREATE TABLE dim_train (
    train_number            VARCHAR(10)  PRIMARY KEY,
    train_name              VARCHAR(120) NOT NULL,
    train_category          VARCHAR(40)  NOT NULL,
    origin_code             VARCHAR(10),
    destination_code        VARCHAR(10),
    num_intermediate_stops  INT,
    route_stops             VARCHAR(255),
    FOREIGN KEY (origin_code)      REFERENCES dim_station(station_code),
    FOREIGN KEY (destination_code) REFERENCES dim_station(station_code)
);

-- ---------------------------------------------------------------------------
-- Dimension: date
-- ---------------------------------------------------------------------------
CREATE TABLE dim_date (
    date_key      DATE PRIMARY KEY,
    year          SMALLINT,
    month         TINYINT,
    month_name    VARCHAR(3),
    quarter       VARCHAR(2),
    week_of_year  TINYINT,
    day_of_week   VARCHAR(10),
    day_type      VARCHAR(10),
    season        VARCHAR(30),
    is_monsoon    TINYINT(1)
);

-- ---------------------------------------------------------------------------
-- Fact: one row per train run
-- ---------------------------------------------------------------------------
CREATE TABLE fact_train_runs (
    run_id                        INT PRIMARY KEY,
    train_number                  VARCHAR(10) NOT NULL,
    run_date                      DATE NOT NULL,
    origin_code                   VARCHAR(10),
    destination_code              VARCHAR(10),
    scheduled_departure           DATETIME,
    actual_departure              DATETIME NULL,
    scheduled_arrival             DATETIME,
    actual_arrival                DATETIME NULL,
    arrival_delay_min             DECIMAL(7,1) NULL,
    departure_delay_min           DECIMAL(7,1) NULL,
    is_cancelled                  TINYINT(1) NOT NULL DEFAULT 0,
    bottleneck_stops_on_route     INT,
    route_stops                   VARCHAR(255),
    is_on_time                    DECIMAL(3,1) NULL,
    delay_bucket                  VARCHAR(20),
    departure_hour                TINYINT,
    time_band                     VARCHAR(20),
    day_of_week                   VARCHAR(10),
    day_type                      VARCHAR(10),
    month                         TINYINT,
    season                        VARCHAR(30),
    route_has_bottleneck          TINYINT(1),
    INDEX idx_run_date (run_date),
    INDEX idx_train (train_number),
    INDEX idx_origin (origin_code),
    FOREIGN KEY (train_number) REFERENCES dim_train(train_number)
);

-- ---------------------------------------------------------------------------
-- Data quality log (from clean_and_transform.py)
-- ---------------------------------------------------------------------------
CREATE TABLE data_quality_log (
    step           VARCHAR(80),
    rows_affected  INT,
    note           VARCHAR(255)
);

-- ---------------------------------------------------------------------------
-- Load data
-- Adjust the path to where your data/processed folder lives.
-- Requires local_infile enabled: SET GLOBAL local_infile = 1;
-- ---------------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/processed/dim_station.csv'
INTO TABLE dim_station
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

LOAD DATA LOCAL INFILE 'data/processed/dim_train.csv'
INTO TABLE dim_train
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(train_number, train_name, train_category, origin_code, destination_code,
 num_intermediate_stops, route_stops);

LOAD DATA LOCAL INFILE 'data/processed/dim_date.csv'
INTO TABLE dim_date
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(@date, year, month, month_name, quarter, week_of_year, day_of_week, day_type, season, is_monsoon)
SET date_key = STR_TO_DATE(@date, '%Y-%m-%d');

LOAD DATA LOCAL INFILE 'data/processed/fact_train_runs.csv'
INTO TABLE fact_train_runs
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(run_id, train_number, @run_date, origin_code, destination_code,
 @orig_name, @dest_name, @sched_dep, @act_dep, @sched_arr, @act_arr,
 @arr_delay, @dep_delay, is_cancelled, bottleneck_stops_on_route, route_stops,
 @is_on_time_raw, delay_bucket, departure_hour, time_band, day_of_week, day_type,
 month, @month_name, season, @delay_avg, route_has_bottleneck)
SET
    run_date            = STR_TO_DATE(@run_date,  '%Y-%m-%d'),
    scheduled_departure = STR_TO_DATE(@sched_dep, '%Y-%m-%d %H:%i:%s'),
    actual_departure    = NULLIF(STR_TO_DATE(@act_dep,   '%Y-%m-%d %H:%i:%s'), '0000-00-00 00:00:00'),
    scheduled_arrival   = STR_TO_DATE(@sched_arr, '%Y-%m-%d %H:%i:%s'),
    actual_arrival      = NULLIF(STR_TO_DATE(@act_arr,   '%Y-%m-%d %H:%i:%s'), '0000-00-00 00:00:00'),
    arrival_delay_min   = NULLIF(@arr_delay, ''),
    departure_delay_min = NULLIF(@dep_delay, ''),
    is_on_time          = NULLIF(@is_on_time_raw, '');

-- Load the data quality log last
LOAD DATA LOCAL INFILE 'data/processed/data_quality_log.csv'
INTO TABLE data_quality_log
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

-- Quick sanity checks
SELECT 'stations' AS tbl, COUNT(*) AS rows_loaded FROM dim_station
UNION ALL SELECT 'trains', COUNT(*) FROM dim_train
UNION ALL SELECT 'dates', COUNT(*) FROM dim_date
UNION ALL SELECT 'train_runs', COUNT(*) FROM fact_train_runs;
